﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UniversityApplication.Data;
using UniversityApplication.Data.Entities;
using UniversityApplication.Models.DTOs;
using UniversityApplication.Service.Interfaces;

namespace UniversityApplication.Service.Services
{
    public class ClubService : IClubService
    {
        private readonly UniversityDataContext _dataContext;

        public ClubService(UniversityDataContext dataContext)
        {
            _dataContext = dataContext;
        }

        public async Task<Club> GetClubById(int id)
        {
            return await _dataContext.Club.FirstOrDefaultAsync(x => x.Id == id);
        }

        public async Task<IEnumerable<Club>> GetClub()
        {
            return await _dataContext.Club.ToListAsync();
        }

        public ClubDTO AddClub(ClubDTO Player)
        {
            throw new NotImplementedException();
        }

        public ClubDTO UpdateClub(ClubDTO Player)
        {
            throw new NotImplementedException();
        }

        public Task<bool> DeleteClub(int id)
        {
            throw new NotImplementedException();
        }
    }
}
