﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UniversityApplication.Data;
using UniversityApplication.Data.Entities;
using UniversityApplication.Models.DTOs;
using UniversityApplication.Service.Interfaces;
using AutoMapper;

namespace UniversityApplication.Service.Services
{
    public class PlayerService : IPlayerService
    {
        private readonly UniversityDataContext _dataContext;
        private readonly IMapper _mapper;

        public PlayerService(UniversityDataContext dataContext, IMapper mapper)
        {
            _dataContext = dataContext;
            _mapper = mapper;
        }

        public IEnumerable<PlayerDTO> GetPlayers()
        {
            var Players = _dataContext.Players.Include(s => s.Club);
            return _mapper.Map<IEnumerable<PlayerDTO>>(Players);
        }

        public async Task<PlayerDTO> GetPlayerById(int id)
        {
            var Player = await _dataContext.Players.Include(s => s.Club).FirstOrDefaultAsync(x => x.Id == id);
            return _mapper.Map<PlayerDTO>(Player);
        }

        public PlayerDTO AddPlayer(PlayerDTO Player)
        {
            Player newPlayer = _mapper.Map<Player>(Player);

            if (_dataContext.Players.FirstOrDefault(s => s.Id == Player.Id) == null)
            {
                _dataContext.Players.Add(newPlayer);
                _dataContext.SaveChanges();
            }
            return _mapper.Map<PlayerDTO>(newPlayer);
        }

        public PlayerDTO UpdatePlayer(PlayerDTO Player)
        {
            Player newPlayer = _mapper.Map<Player>(Player);
            Player oldPlayer = _dataContext.Players.FirstOrDefault(s => s.Id == newPlayer.Id);

            if (oldPlayer != null)
            {
                _dataContext.Entry(oldPlayer).CurrentValues.SetValues(newPlayer);
                _dataContext.SaveChanges();
            }
            return _mapper.Map<PlayerDTO>(newPlayer);
        }

        public async Task<bool> DeletePlayer(int id)
        {
            var PlayerEntity = await _dataContext.Players.FindAsync(id);
            _dataContext.Players.Remove(PlayerEntity);
            return await SaveAsync() > 0;
        }

        public async Task<int> SaveAsync()
        {
            return await _dataContext.SaveChangesAsync();
        }
    }
}
