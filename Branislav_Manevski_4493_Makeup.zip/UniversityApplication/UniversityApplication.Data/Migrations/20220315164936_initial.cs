﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace UniversityApplication.Data.Migrations
{
    public partial class initial : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Club",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(400)", maxLength: 400, nullable: true),
                    Owner = table.Column<string>(type: "nvarchar(400)", maxLength: 400, nullable: true),
                    City = table.Column<string>(type: "nvarchar(400)", maxLength: 400, nullable: true),
                    Country = table.Column<string>(type: "nvarchar(400)", maxLength: 400, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Club", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Players",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    FirstName = table.Column<string>(type: "nvarchar(200)", maxLength: 200, nullable: true),
                    LastName = table.Column<string>(type: "nvarchar(400)", maxLength: 400, nullable: true),
                    DateOfBirth = table.Column<DateTime>(type: "datetime", nullable: true),
                    SigningDate = table.Column<DateTime>(type: "datetime", nullable: true),
                    Rank = table.Column<int>(type: "int", nullable: false),
                    TotalGoals = table.Column<int>(type: "int", nullable: false),
                    ClubId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Players", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Players_Club_ClubId",
                        column: x => x.ClubId,
                        principalTable: "Club",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.InsertData(
                table: "Club",
                columns: new[] { "Id", "City", "Country", "Name", "Owner" },
                values: new object[,]
                {
                    { 1, "Paris", "France", "PSG", "Kire" },
                    { 2, "London", "UK", "Chelsea", "Tome" },
                    { 3, "Barcelona", "Spain", "Barcelona", "Stefan" },
                    { 4, "London", "England", "Arsenal", "Nikola" },
                    { 5, "Berlin", "Germany", "Bayern", "Filip" }
                });

            migrationBuilder.InsertData(
                table: "Players",
                columns: new[] { "Id", "ClubId", "DateOfBirth", "FirstName", "LastName", "Rank", "SigningDate", "TotalGoals" },
                values: new object[,]
                {
                    { 1, 2, new DateTime(1995, 3, 15, 0, 0, 0, 0, DateTimeKind.Local), "Herbert", "Collins", 1, new DateTime(2021, 3, 15, 0, 0, 0, 0, DateTimeKind.Local), 40 },
                    { 2, 2, new DateTime(2002, 3, 15, 0, 0, 0, 0, DateTimeKind.Local), "Elmer", "Wintringham", 2, new DateTime(2020, 3, 15, 0, 0, 0, 0, DateTimeKind.Local), 30 },
                    { 3, 2, new DateTime(1991, 3, 15, 0, 0, 0, 0, DateTimeKind.Local), "Daley", "Simon", 3, new DateTime(2019, 3, 15, 0, 0, 0, 0, DateTimeKind.Local), 25 },
                    { 4, 2, new DateTime(1998, 3, 15, 0, 0, 0, 0, DateTimeKind.Local), "Cassandra", "Holden", 4, new DateTime(2018, 3, 15, 0, 0, 0, 0, DateTimeKind.Local), 20 },
                    { 5, 2, new DateTime(2003, 3, 15, 0, 0, 0, 0, DateTimeKind.Local), "Norman", "Geis", 5, new DateTime(2017, 3, 15, 0, 0, 0, 0, DateTimeKind.Local), 10 }
                });

            migrationBuilder.CreateIndex(
                name: "IX_Players_ClubId",
                table: "Players",
                column: "ClubId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Players");

            migrationBuilder.DropTable(
                name: "Club");
        }
    }
}
